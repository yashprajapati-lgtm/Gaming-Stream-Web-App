const express = require("express");
const Stream = require("../models/Stream");
const auth = require("../middleware/auth.middleware");

const router = express.Router();

// Create Stream
router.post("/create", auth, async (req, res) => {
  const stream = new Stream({
    title: req.body.title,
    game: req.body.game,
    streamer: req.body.streamer,
    isLive: true,
    viewers: 0
  });

  await stream.save();
  res.json({ message: "Stream created" });
});

// Get Live Streams
router.get("/live", async (req, res) => {
  const streams = await Stream.find({ isLive: true });
  res.json(streams);
});

module.exports = router;
