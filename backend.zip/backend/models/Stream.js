const mongoose = require("mongoose");

const StreamSchema = new mongoose.Schema({
  title: String,
  game: String,
  streamer: String,
  isLive: Boolean,
  viewers: Number
});

module.exports = mongoose.model("Stream", StreamSchema);
